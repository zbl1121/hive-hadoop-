package com.zbl.analyse.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class weather implements Serializable {
    private static final long serialVersionUID = 1L;

    private Float ww;
    //年月
    private String weather;
    //Ff
    private Integer count;
}
