package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.weather;
import com.zbl.analyse.mapper.weatherMapper;
import com.zbl.analyse.service.weatherService;
import org.springframework.stereotype.Service;

@Service
public class weatherServiceImpl extends ServiceImpl<weatherMapper, weather> implements weatherService {
}
