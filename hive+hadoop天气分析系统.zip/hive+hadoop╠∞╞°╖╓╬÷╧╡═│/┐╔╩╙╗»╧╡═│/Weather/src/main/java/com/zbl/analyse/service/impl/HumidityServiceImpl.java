package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.Humidity;
import com.zbl.analyse.mapper.HumidityMapper;
import com.zbl.analyse.service.HumidityService;
import org.springframework.stereotype.Service;

@Service
public class HumidityServiceImpl extends ServiceImpl<HumidityMapper, Humidity> implements HumidityService {
}
