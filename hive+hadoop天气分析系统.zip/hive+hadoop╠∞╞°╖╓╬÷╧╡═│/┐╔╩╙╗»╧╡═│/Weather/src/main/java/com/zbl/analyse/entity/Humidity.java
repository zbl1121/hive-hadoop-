package com.zbl.analyse.entity;

import lombok.Data;

import java.io.Serializable;

//湿度信息
@Data
public class Humidity implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    //年月
    private String time;
    //最大湿度
    private Float maxH;
    //最小湿度
    private Float minH;
    //平均湿度
    private Float avgH;
}
