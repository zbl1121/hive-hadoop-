package com.zbl.analyse.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class minTpo implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    //年月
    private String time1;
    //时间
    private String time2;
    //最大温度
    private Float minT;
    //大气压
    private Float po;
}
