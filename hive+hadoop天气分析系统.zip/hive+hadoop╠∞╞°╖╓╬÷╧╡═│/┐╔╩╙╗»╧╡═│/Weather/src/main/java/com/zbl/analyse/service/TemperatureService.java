package com.zbl.analyse.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zbl.analyse.entity.Temperature;

public interface TemperatureService extends IService<Temperature> {
}
