package com.zbl.analyse.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zbl.analyse.entity.weather;

public interface weatherService extends IService<weather> {
}
