package com.zbl.analyse.entity;

import lombok.Data;

import java.io.Serializable;

//温度信息
@Data
public class Temperature implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    //年月
    private String time;
    //最大温度
    private Float maxT;
    //最小温度
    private Float minT;
    //平均温度
    private Float avgT;
}
