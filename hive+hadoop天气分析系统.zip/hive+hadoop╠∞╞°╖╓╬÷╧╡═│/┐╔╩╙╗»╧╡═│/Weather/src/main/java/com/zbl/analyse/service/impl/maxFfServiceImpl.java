package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.maxFf;
import com.zbl.analyse.mapper.maxFfMapper;
import com.zbl.analyse.service.maxFfService;
import org.springframework.stereotype.Service;

@Service
public class maxFfServiceImpl extends ServiceImpl<maxFfMapper, maxFf> implements maxFfService {
}
