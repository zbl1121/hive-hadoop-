package com.zbl.analyse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zbl.analyse.entity.Temperature;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TemperatureMapper extends BaseMapper<Temperature> {
}