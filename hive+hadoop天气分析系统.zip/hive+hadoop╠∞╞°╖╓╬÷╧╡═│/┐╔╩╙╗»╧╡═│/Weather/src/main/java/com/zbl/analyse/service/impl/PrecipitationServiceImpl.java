package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.Precipitation;
import com.zbl.analyse.mapper.PrecipitationMapper;
import com.zbl.analyse.service.PrecipitationService;
import org.springframework.stereotype.Service;

@Service
public class PrecipitationServiceImpl extends ServiceImpl<PrecipitationMapper, Precipitation> implements PrecipitationService {
}
