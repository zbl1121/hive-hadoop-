package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.minTpo;
import com.zbl.analyse.mapper.minTpoMapper;
import com.zbl.analyse.service.minTpoService;
import org.springframework.stereotype.Service;

@Service
public class minTpoServiceImpl extends ServiceImpl<minTpoMapper, minTpo> implements minTpoService {
}
