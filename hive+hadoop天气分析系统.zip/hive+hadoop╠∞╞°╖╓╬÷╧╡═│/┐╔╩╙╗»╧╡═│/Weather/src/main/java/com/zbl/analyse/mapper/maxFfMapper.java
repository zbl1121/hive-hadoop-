package com.zbl.analyse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zbl.analyse.entity.maxFf;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface maxFfMapper extends BaseMapper<maxFf> {
}