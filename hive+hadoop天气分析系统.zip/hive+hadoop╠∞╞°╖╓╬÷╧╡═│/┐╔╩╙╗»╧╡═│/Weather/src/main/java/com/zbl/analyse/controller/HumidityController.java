package com.zbl.analyse.controller;

import com.zbl.analyse.common.R;
import com.zbl.analyse.entity.Humidity;
import com.zbl.analyse.service.HumidityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/humidity")
public class HumidityController {
    @Autowired
    private HumidityService humidityService;
    @GetMapping("/list")
    public R<List<Humidity>> listAll() {
        log.info("获取所有数据");

        // 执行查询
        List<Humidity> humidityList = humidityService.list();

        return R.success(humidityList);
    }

}
