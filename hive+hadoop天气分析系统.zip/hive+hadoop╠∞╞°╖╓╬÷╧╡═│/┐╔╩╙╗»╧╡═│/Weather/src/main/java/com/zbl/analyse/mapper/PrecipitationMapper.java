package com.zbl.analyse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zbl.analyse.entity.Precipitation;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PrecipitationMapper extends BaseMapper<Precipitation> {
}