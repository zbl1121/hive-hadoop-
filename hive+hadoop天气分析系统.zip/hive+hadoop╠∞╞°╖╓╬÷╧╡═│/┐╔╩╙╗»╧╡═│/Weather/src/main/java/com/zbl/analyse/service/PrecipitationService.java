package com.zbl.analyse.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zbl.analyse.entity.Precipitation;

public interface PrecipitationService extends IService<Precipitation> {
}
