package com.zbl.analyse.controller;

import com.zbl.analyse.common.R;
import com.zbl.analyse.entity.maxFf;
import com.zbl.analyse.service.maxFfService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/maxFf")
public class maxFfController {
    @Autowired
    private maxFfService maxFfService;
    @GetMapping("/list")
    public R<List<maxFf>> listAll() {
        log.info("获取所有数据");

        // 执行查询
        List<maxFf> maxFfList = maxFfService.list();

        return R.success(maxFfList);
    }

}
