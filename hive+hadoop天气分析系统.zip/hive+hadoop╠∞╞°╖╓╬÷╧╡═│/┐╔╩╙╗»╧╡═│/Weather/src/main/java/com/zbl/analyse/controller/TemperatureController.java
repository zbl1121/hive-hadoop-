package com.zbl.analyse.controller;

import com.zbl.analyse.common.R;
import com.zbl.analyse.entity.Temperature;
import com.zbl.analyse.service.TemperatureService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/temperature")
public class TemperatureController {
    @Autowired
    private TemperatureService temperatureService;
    @GetMapping("/list")
    public R<List<Temperature>> listAll() {
        log.info("获取所有数据");

        // 执行查询
        List<Temperature> temperatureList = temperatureService.list();

        return R.success(temperatureList);
    }

}
