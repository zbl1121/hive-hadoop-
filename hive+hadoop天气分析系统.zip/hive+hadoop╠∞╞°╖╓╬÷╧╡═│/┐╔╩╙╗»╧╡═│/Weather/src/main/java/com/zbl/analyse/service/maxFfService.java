package com.zbl.analyse.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zbl.analyse.entity.maxFf;

public interface maxFfService extends IService<maxFf> {
}
