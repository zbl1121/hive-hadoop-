package com.zbl.analyse.entity;

import lombok.Data;

import java.io.Serializable;

//湿度信息
@Data
public class Precipitation implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    //年月
    private String time;
    //最大湿度
    private Float maxP;
    //最小湿度
    private Float minP;
    //平均湿度
    private Float avgP;
}
