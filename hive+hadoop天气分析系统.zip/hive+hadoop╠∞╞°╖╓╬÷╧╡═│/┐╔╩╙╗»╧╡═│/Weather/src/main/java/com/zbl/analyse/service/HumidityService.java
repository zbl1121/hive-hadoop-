package com.zbl.analyse.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zbl.analyse.entity.Humidity;

public interface HumidityService extends IService<Humidity> {
}
