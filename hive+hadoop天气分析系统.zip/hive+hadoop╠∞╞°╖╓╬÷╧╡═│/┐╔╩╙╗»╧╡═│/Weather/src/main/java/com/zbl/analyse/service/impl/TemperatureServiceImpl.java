package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.Temperature;
import com.zbl.analyse.mapper.TemperatureMapper;
import com.zbl.analyse.service.TemperatureService;
import org.springframework.stereotype.Service;

@Service
public class TemperatureServiceImpl extends ServiceImpl<TemperatureMapper, Temperature> implements TemperatureService {
}
