package com.zbl.analyse.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zbl.analyse.entity.maxTpo;
import com.zbl.analyse.mapper.maxTpoMapper;
import com.zbl.analyse.service.maxTpoService;
import org.springframework.stereotype.Service;

@Service
public class maxTpoServiceImpl extends ServiceImpl<maxTpoMapper, maxTpo> implements maxTpoService {
}
