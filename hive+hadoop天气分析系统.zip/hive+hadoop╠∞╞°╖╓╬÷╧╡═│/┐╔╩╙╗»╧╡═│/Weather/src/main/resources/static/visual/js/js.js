﻿
$(function () {
echarts_1();
echarts_2();
echarts_4();
echarts_3();
echarts_5();
echarts_6();
function echarts_1() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart1'));
    axios.get('/maxFf/list')
        .then(response => {
            // 从响应中获取数据
            const responseData = response.data.data;
            const lastTenItems = responseData.slice(-10);
            const time1 = lastTenItems.map(item => item.time1);
            const time2 = lastTenItems.map(item => item.time2);
            const MaxWind = lastTenItems.map(item => item.ff);
            // 将 time1 和 time2 连接在一起，以 "-" 分隔
            const combinedTimes = time1.map((t1, index) => `${t1}-${time2[index]}`);

            option = {
                //  backgroundColor: '#00265f',
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                grid: {
                    left: '0%',
                    top:'10px',
                    right: '0%',
                    bottom: '4%',
                    containLabel: true
                },
                xAxis: [{
                    type: 'category',
                    data: combinedTimes,
                    axisLine: {
                        show: true,
                        lineStyle: {
                            color: "rgba(255,255,255,.1)",
                            width: 1,
                            type: "solid"
                        },
                    },

                    axisTick: {
                        show: false,
                    },
                    axisLabel:  {
                        interval: 0,
                        rotate:30,
                        show: true,
                        splitNumber: 15,
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize: '12',
                        },
                    },
                }],
                yAxis: [{
                    type: 'value',
                    axisLabel: {
                        //formatter: '{value} %'
                        show:true,
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize: '12',
                        },
                    },
                    axisTick: {
                        show: false,
                    },
                    axisLine: {
                        show: true,
                        lineStyle: {
                            color: "rgba(255,255,255,.1	)",
                            width: 1,
                            type: "solid"
                        },
                    },
                    splitLine: {
                        lineStyle: {
                            color: "rgba(255,255,255,.1)",
                        }
                    }
                }],
                series: [
                    {
                        type: 'bar',
                        data: MaxWind,
                        barWidth:'35%', //柱子宽度
                        // barGap: 1, //柱子之间间距
                        itemStyle: {
                            normal: {
                                color:'#05b92f',
                                opacity: 1,
                                barBorderRadius: 5,
                            }
                        }
                    }

                ]
            };

            // 使用更新后的配置项重新渲染图表
            myChart.setOption(option);
        })
        .catch(error => {
            console.error('Error fetching humidity data:', error);
        });

        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
function echarts_2() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart2'));

    axios.get('/maxTpo/list')
        .then(response => {
            // 从响应中获取数据
            const responseData = response.data.data;
            const lastTenItems = responseData.slice(-10);
            const maxPoData = lastTenItems.map(item => item.maxPo);
            const minPoData = lastTenItems.map(item => item.minPo);
            const years = lastTenItems.map(item => item.time1);
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#dddc6b'
                        }
                    }
                },
                legend: {
                    top:'0%',
                    data:['最大温度对应的大气压','最小温度对应的大气压'],
                    textStyle: {
                        color: 'rgba(255,255,255,.5)',
                        fontSize:'12',
                    }
                },
                grid: {
                    left: '10',
                    top: '30',
                    right: '10',
                    bottom: '10',
                    containLabel: true
                },

                xAxis: [{
                    type: 'category',
                    boundaryGap: false,
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                        rotate: 45  // 将横坐标文字旋转45度
                    },
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.2)'
                        }

                    },

                    data: years

                }, {

                    axisPointer: {show: false},
                    axisLine: {  show: false},
                    position: 'bottom',
                    offset: 20,



                }],

                yAxis: [{
                    type: 'value',
                    min: Math.min(...minPoData), // 设置最小值为最小温度对应的大气压中的最小值
                    max: Math.max(...maxPoData), // 设置最大值为最大温度对应的大气压中的最大值
                    axisTick: {show: false},
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    },
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                    },

                    splitLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    }
                }],
                series: [
                    {
                        name: '最大温度对应的大气压',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#0184d5',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(1, 132, 213, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(1, 132, 213, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#0184d5',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: minPoData

                    },
                    {
                        name: '最小温度对应的大气压',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#00d887',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(0, 216, 135, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(0, 216, 135, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#00d887',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: maxPoData

                    },

                ]

            };
            // 使用更新后的配置项重新渲染图表
            myChart.setOption(option);
        })
        .catch(error => {
            console.error('Error fetching humidity data:', error);
        });

        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
function echarts_5() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart5'));

    axios.get('/temperature/list')
        .then(response => {
            // 从响应中获取数据
            const responseData = response.data.data;
            const lastTenItems = responseData.slice(-10);
            const maxTemperatureData = lastTenItems.map(item => item.maxT);
            const minTemperatureData = lastTenItems.map(item => item.minT);
            const avgTemperatureData = lastTenItems.map(item => item.avgT);
            const years = lastTenItems.map(item => item.time);
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#dddc6b'
                        }
                    }
                },
                legend: {
                    top:'0%',
                    data:['最大温度','最小温度','平均温度'],
                    textStyle: {
                        color: 'rgba(255,255,255,.5)',
                        fontSize:'12',
                    }
                },
                grid: {
                    left: '10',
                    top: '30',
                    right: '10',
                    bottom: '10',
                    containLabel: true
                },

                xAxis: [{
                    type: 'category',
                    boundaryGap: false,
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                        rotate: 45  // 将横坐标文字旋转45度
                    },
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.2)'
                        }

                    },

                    data: years

                }, {

                    axisPointer: {show: false},
                    axisLine: {  show: false},
                    position: 'bottom',
                    offset: 20,



                }],

                yAxis: [{
                    type: 'value',
                    axisTick: {show: false},
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    },
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                    },

                    splitLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    }
                }],
                series: [
                    {
                        name: '最大温度',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#0184d5',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(1, 132, 213, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(1, 132, 213, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#0184d5',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: maxTemperatureData

                    },
                    {
                        name: '最小温度',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#00d887',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(0, 216, 135, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(0, 216, 135, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#00d887',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: minTemperatureData

                    },
                    {
                        name: '平均温度',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#FA8072',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(255, 0, 0, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(255, 0, 0, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#FA8072',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: avgTemperatureData

                    },

                ]

            };
            // 使用更新后的配置项重新渲染图表
            myChart.setOption(option);
        })
        .catch(error => {
            console.error('Error fetching humidity data:', error);
        });

        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
	
function echarts_4() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart4'));
    // 使用 Axios 发起 GET 请求到后端的 API 接口
    axios.get('/humidity/list')
        .then(response => {
            // 从响应中获取数据
            const responseData = response.data.data;
            // 提取最大湿度和最小湿度的数据数组
            const lastTenItems = responseData.slice(-10);
            const maxHumidityData = lastTenItems.map(item => item.maxH);
            const minHumidityData = lastTenItems.map(item => item.minH);
            const avgHumidityData = lastTenItems.map(item => item.avgH);
            const years = lastTenItems.map(item => item.time);
            console.log(maxHumidityData);
            // // // 更新图表的 data 属性为获取到的数据
            // option.series[0].data = maxHumidityData;
            // option.series[1].data = minHumidityData;
            // // // 使用更新后的配置项重新渲染图表
            // myChart.setOption(option);
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#dddc6b'
                        }
                    }
                },
                legend: {
                    top:'0%',
                    data:['最大湿度','最小湿度','平均湿度'],
                    textStyle: {
                        color: 'rgba(255,255,255,.5)',
                        fontSize:'12',
                    }
                },
                grid: {
                    left: '10',
                    top: '30',
                    right: '10',
                    bottom: '10',
                    containLabel: true
                },

                xAxis: [{
                    type: 'category',
                    boundaryGap: false,
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                        rotate: 45  // 将横坐标文字旋转45度
                    },
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.2)'
                        }

                    },

                    data: years

                }, {

                    axisPointer: {show: false},
                    axisLine: {  show: false},
                    position: 'bottom',
                    offset: 20,



                }],

                yAxis: [{
                    type: 'value',
                    axisTick: {show: false},
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    },
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                    },

                    splitLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    }
                }],
                series: [
                    {
                        name: '最大湿度',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#0184d5',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(1, 132, 213, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(1, 132, 213, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#0184d5',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: maxHumidityData

                    },
                    {
                        name: '最小湿度',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#00d887',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(0, 216, 135, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(0, 216, 135, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#00d887',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: minHumidityData

                    },
                    {
                        name: '平均湿度',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#FA8072',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(255, 0, 0, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(255, 0, 0, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#FA8072',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: avgHumidityData

                    },

                ]

            };
            // 使用更新后的配置项重新渲染图表
            myChart.setOption(option);
        })
        .catch(error => {
            console.error('Error fetching humidity data:', error);
        });


      
        // 使用刚指定的配置项和数据显示图表。
        //myChart.setOption(option);
        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
function echarts_6() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart6'));

    axios.get('/precipitation/list')
        .then(response => {
            // 从响应中获取数据
            const responseData = response.data.data;
            const maxPrecipitationData = responseData.map(item => item.maxP);
            const minPrecipitationData = responseData.map(item => item.minP);
            const avgPrecipitationData = responseData.map(item => item.avgP);
            const years = responseData.map(item => item.time);
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#dddc6b'
                        }
                    }
                },
                legend: {
                    top:'0%',
                    data:['最大降水量','最小降水量','平均降水量'],
                    textStyle: {
                        color: 'rgba(255,255,255,.5)',
                        fontSize:'12',
                    }
                },
                grid: {
                    left: '10',
                    top: '30',
                    right: '10',
                    bottom: '10',
                    containLabel: true
                },

                xAxis: [{
                    type: 'category',
                    boundaryGap: false,
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                        rotate: 45  // 将横坐标文字旋转45度
                    },
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.2)'
                        }

                    },

                    data: years

                }, {

                    axisPointer: {show: false},
                    axisLine: {  show: false},
                    position: 'bottom',
                    offset: 20,



                }],

                yAxis: [{
                    type: 'value',
                    min: Math.min(...minPrecipitationData), // 设置最小值为最小温度对应的大气压中的最小值
                    max: Math.max(...maxPrecipitationData), // 设置最大值为最大温度对应的大气压中的最大值
                    axisTick: {show: false},
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    },
                    axisLabel:  {
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize:12,
                        },
                    },

                    splitLine: {
                        lineStyle: {
                            color: 'rgba(255,255,255,.1)'
                        }
                    }
                }],
                series: [
                    {
                        name: '最大降水量',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#0184d5',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(1, 132, 213, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(1, 132, 213, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#0184d5',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: maxPrecipitationData

                    },
                    {
                        name: '最小降水量',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#00d887',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(0, 216, 135, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(0, 216, 135, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#00d887',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: minPrecipitationData

                    },
                    {
                        name: '平均降水量',
                        type: 'line',
                        smooth: true,
                        symbol: 'circle',
                        symbolSize: 5,
                        showSymbol: false,
                        lineStyle: {

                            normal: {
                                color: '#FA8072',
                                width: 2
                            }
                        },
                        areaStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(255, 0, 0, 0.4)'
                                }, {
                                    offset: 0.8,
                                    color: 'rgba(255, 0, 0, 0.1)'
                                }], false),
                                shadowColor: 'rgba(0, 0, 0, 0.1)',
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#FA8072',
                                borderColor: 'rgba(221, 220, 107, .1)',
                                borderWidth: 12
                            }
                        },
                        data: avgPrecipitationData

                    },

                ]

            };
            // 使用更新后的配置项重新渲染图表
            myChart.setOption(option);
        })
        .catch(error => {
            console.error('Error fetching humidity data:', error);
        });

        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
    function echarts_3() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart3'));

        var dataStyle = {
            normal: {
                label: {
                    show: false
                },
                labelLine: {
                    show: false
                },
                //shadowBlur: 40,
                //shadowColor: 'rgba(40, 40, 40, 1)',
            }
        };
        var placeHolderStyle = {
            normal: {
                color: 'rgba(255,255,255,.05)',
                label: {show: false,},
                labelLine: {show: false}
            },
            emphasis: {
                color: 'rgba(0,0,0,0)'
            }
        };

        axios.get('/weather/list')
            .then(response => {
                // 从响应中获取数据
                const responseData = response.data.data;
                const weatherData = responseData.map(item => item.weather);
                const countData = responseData.map(item => item.count);
                console.log(responseData)

                option = {
                    color: ['#0f63d6', '#0f78d6', '#0f8cd6', '#0fa0d6', '#0fb4d6'],
                    tooltip: {
                        show: true,
                        formatter: "{a} : {c} "
                    },
                    legend: {
                        itemWidth: 10,
                        itemHeight: 10,
                        itemGap: 12,
                        bottom: '3%',

                        data: weatherData,
                        textStyle: {
                            color: 'rgba(255,255,255,.6)',
                        }
                    },

                    series: [
                        {
                            name: weatherData[0],
                            type: 'pie',
                            clockWise: false,
                            center: ['50%', '42%'],
                            radius: ['78%', '84%'],
                            itemStyle: dataStyle,
                            hoverAnimation: false,
                            data: [{
                                value: countData[0],
                                name: '01'
                            }, {
                                value: 20,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[1],
                            type: 'pie',
                            clockWise: false,
                            center: ['50%', '42%'],
                            radius: ['72%', '78%'],
                            itemStyle: dataStyle,
                            hoverAnimation: false,
                            data: [{
                                value: countData[1],
                                name: '02'
                            }, {
                                value: 30,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[2],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['66%', '72%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[2],
                                name: '03'
                            }, {
                                value: 35,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[3],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['60%', '66%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[3],
                                name: '04'
                            }, {
                                value: 40,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[4],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['54%', '60%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[4],
                                name: '05'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[5],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['48%', '54%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[5],
                                name: '06'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[6],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['42%', '48%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[6],
                                name: '07'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[7],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['36%', '42%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[7],
                                name: '08'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[8],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['30%', '36%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[8],
                                name: '09'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[9],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['24%', '30%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[9],
                                name: '10'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[10],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['18%', '24%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[10],
                                name: '11'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[11],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['12%', '18%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[11],
                                name: '12'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[12],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['6%', '12%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[12],
                                name: '13'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },
                        {
                            name: weatherData[13],
                            type: 'pie',
                            clockWise: false,
                            hoverAnimation: false,
                            center: ['50%', '42%'],
                            radius: ['0%', '6%'],
                            itemStyle: dataStyle,
                            data: [{
                                value: countData[13],
                                name: '14'
                            }, {
                                value: 50,
                                name: 'invisible',
                                tooltip: {show: false},
                                itemStyle: placeHolderStyle
                            }]
                        },

                    ]
                };

                // 使用更新后的配置项重新渲染图表
                myChart.setOption(option);
            })
            .catch(error => {
                console.error('Error fetching weather data:', error);
            });


        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }

				
	
})



		
		
		


		









