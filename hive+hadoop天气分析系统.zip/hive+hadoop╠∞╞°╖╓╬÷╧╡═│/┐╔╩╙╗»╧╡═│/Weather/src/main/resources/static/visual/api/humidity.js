function getHumidityList (params) {
    return $axios({
        url: '/humidity/list',
        method: 'get',
        params
    })
}